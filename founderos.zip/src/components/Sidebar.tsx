import React from 'react';
import { LayoutDashboard, PenTool, GitPullRequest, Database, Settings as SettingsIcon } from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
    { id: 'drafts', label: 'AI Drafts', icon: <PenTool size={18} /> },
    { id: 'pipeline', label: 'Pipeline', icon: <GitPullRequest size={18} /> },
    { id: 'context', label: 'Context', icon: <Database size={18} /> },
  ];

  return (
    <aside className="w-64 border-r border-border-founderos flex flex-col p-6">
      <div className="mb-12 px-4">
        <h1 className="text-2xl font-serif italic tracking-tight">FounderOS</h1>
        <div className="h-[1px] w-8 bg-accent-founderos mt-2"></div>
      </div>

      <nav className="flex-1 flex flex-col gap-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`sidebar-item ${activeTab === item.id ? 'active' : ''}`}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>

      <div className="mt-auto">
        <button
          onClick={() => setActiveTab('settings')}
          className={`sidebar-item w-full ${activeTab === 'settings' ? 'active' : ''}`}
        >
          <SettingsIcon size={18} />
          Settings
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
