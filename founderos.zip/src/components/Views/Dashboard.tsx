import React, { useEffect, useState } from 'react';
import { useStore } from '../../store';
import { db, handleFirestoreError, OperationType } from '../../services/firebase';
import { collection, query, orderBy, limit, onSnapshot, getDocs } from 'firebase/firestore';
import { motion } from 'motion/react';
import { AlertCircle, TrendingUp, Clock, ArrowRight } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { user } = useStore();
  const [metrics, setMetrics] = useState<any[]>([]);
  const [recentDrafts, setRecentDrafts] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;

    // Fetch metrics
    const metricsPath = `users/${user.uid}/metrics`;
    const metricsUnsubscribe = onSnapshot(collection(db, metricsPath), (snapshot) => {
      const m = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMetrics(m);
    }, (err) => handleFirestoreError(err, OperationType.LIST, metricsPath));

    // Fetch recent drafts
    const draftsPath = `users/${user.uid}/drafts`;
    const draftsQuery = query(collection(db, draftsPath), orderBy('createdAt', 'desc'), limit(3));
    const draftsUnsubscribe = onSnapshot(draftsQuery, (snapshot) => {
      const d = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setRecentDrafts(d);
    }, (err) => handleFirestoreError(err, OperationType.LIST, draftsPath));

    // Simple Alert Logic: Check for stale deals (demo logic)
    const dealsPath = `users/${user.uid}/deals`;
    getDocs(collection(db, dealsPath)).then(snapshot => {
      const deals = snapshot.docs.map(doc => doc.data());
      const now = new Date();
      const twoWeeksAgo = new Date(now.getTime() - (14 * 24 * 60 * 60 * 1000));
      
      const stale = deals.filter((d: any) => {
        const lastContact = new Date(d.lastContactAt);
        return lastContact < twoWeeksAgo && d.stage !== 'closed';
      });

      if (stale.length > 0) {
        setAlerts(prev => [...prev, { 
          id: 'stale-deals', 
          type: 'warning', 
          message: `${stale.length} deals haven't been contacted in 14+ days.`,
          action: 'View Pipeline'
        }]);
      }
    });

    return () => {
      metricsUnsubscribe();
      draftsUnsubscribe();
    };
  }, [user]);

  return (
    <div className="grid grid-cols-12 gap-8">
      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="col-span-12 mb-4">
          {alerts.map(alert => (
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              key={alert.id} 
              className="bg-accent-founderos/10 border border-accent-founderos/20 p-4 rounded-xl flex items-center justify-between"
            >
              <div className="flex items-center gap-3 text-accent-founderos">
                <AlertCircle size={20} />
                <span className="font-medium">{alert.message}</span>
              </div>
              <button className="text-xs font-mono uppercase tracking-widest hover:underline flex items-center gap-2">
                {alert.action} <ArrowRight size={14} />
              </button>
            </motion.div>
          ))}
        </div>
      )}

      {/* Metrics Row */}
      <div className="col-span-12 grid grid-cols-1 md:grid-cols-4 gap-6">
        {metrics.length > 0 ? metrics.map((metric, i) => (
          <div key={metric.id} className="glass-card p-6">
            <div className="text-gray-500 text-xs font-mono uppercase mb-2">{metric.label}</div>
            <div className="text-3xl font-serif italic">${metric.value.toLocaleString()}{metric.unit && <span className="text-lg ml-1">{metric.unit}</span>}</div>
            <div className="mt-4 flex items-center gap-2 text-green-500 text-xs font-medium">
              <TrendingUp size={12} />
              <span>+12% vs last month</span>
            </div>
          </div>
        )) : (
          <div className="col-span-12 glass-card p-12 border-dashed flex flex-col items-center justify-center text-center">
            <div className="mb-4 p-4 rounded-full bg-accent-founderos/10 text-accent-founderos">
              <TrendingUp size={32} />
            </div>
            <h4 className="text-xl font-serif italic mb-2">Initialize your Dashboard</h4>
            <p className="text-gray-500 text-sm max-w-xs mb-6">
              You haven't set up your company metrics yet. Use our defaults to get started.
            </p>
            <button 
              onClick={() => { /* Navigation to Settings would be ideal, but for now we'll just prompt */ 
                alert('Please go to Settings to seed your default metrics.'); 
              }}
              className="px-6 py-2 bg-white text-black rounded-full font-semibold text-sm hover:bg-gray-200 transition-colors"
            >
              Configure FounderOS
            </button>
          </div>
        )}
      </div>

      {/* Main Content Areas */}
      <div className="col-span-12 lg:col-span-8">
        <h3 className="text-xl font-serif italic mb-6">Pipeline Velocity</h3>
        <div className="glass-card h-80 flex flex-col p-8 relative">
          <div className="flex justify-between items-end h-full gap-2">
            {[40, 70, 45, 90, 65, 85, 100].map((height, i) => (
              <div key={i} className="flex-1 flex flex-col items-center group relative">
                <motion.div 
                  initial={{ height: 0 }}
                  animate={{ height: `${height}%` }}
                  transition={{ delay: i * 0.1, duration: 0.8, ease: "easeOut" }}
                  className="w-full bg-accent-founderos/20 border-t border-accent-founderos/40 rounded-t-sm group-hover:bg-accent-founderos/40 transition-colors"
                />
                <div className="text-[8px] font-mono text-gray-600 mt-2 uppercase">Week {i + 1}</div>
                {/* Tooltip */}
                <div className="absolute -top-8 bg-white text-black text-[10px] font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
                  ${(height * 1234).toLocaleString()} Projected
                </div>
              </div>
            ))}
          </div>
          <div className="absolute top-8 right-8 flex items-center gap-4 text-[10px] font-mono text-gray-500 uppercase">
            <div className="flex items-center gap-1"><div className="w-2 h-2 bg-accent-founderos"></div> Qualified</div>
            <div className="flex items-center gap-1"><div className="w-2 h-2 bg-gray-700"></div> Target</div>
          </div>
        </div>
      </div>

      <div className="col-span-12 lg:col-span-4">
        <h3 className="text-xl font-serif italic mb-6">Recent Work</h3>
        <div className="flex flex-col gap-4">
          {recentDrafts.length > 0 ? recentDrafts.map(draft => (
            <div key={draft.id} className="glass-card p-4 hover:bg-white/5 transition-colors cursor-pointer group">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono text-accent-founderos uppercase">{draft.type || 'Draft'}</span>
                <span className="text-[10px] text-gray-500"><Clock size={10} className="inline mr-1" /> {new Date(draft.createdAt).toLocaleDateString()}</span>
              </div>
              <div className="text-sm font-medium line-clamp-1 group-hover:text-accent-founderos transition-colors">{draft.title || 'Untitled Draft'}</div>
            </div>
          )) : (
            <div className="text-center py-12 text-gray-500 italic text-sm">
              No drafts generated yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
