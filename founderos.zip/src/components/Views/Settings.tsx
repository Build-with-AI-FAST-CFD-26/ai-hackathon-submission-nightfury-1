import React from 'react';
import { useStore } from '../../store';
import { db, handleFirestoreError, OperationType } from '../../services/firebase';
import { collection, addDoc, getDocs, deleteDoc, query } from 'firebase/firestore';
import { Trash2, Database, Shield, Zap } from 'lucide-react';

const Settings: React.FC = () => {
  const { user } = useStore();

  const seedMetrics = async () => {
    if (!user) return;
    const metricsPath = `users/${user.uid}/metrics`;
    try {
      // Clear existing
      const existing = await getDocs(collection(db, metricsPath));
      await Promise.all(existing.docs.map(d => deleteDoc(d.ref)));

      // Add defaults
      const defaults = [
        { label: 'MRR', value: 42000, unit: '', ownerId: user.uid },
        { label: 'Runway', value: 18, unit: 'mo', ownerId: user.uid },
        { label: 'Burn Rate', value: 12500, unit: '/mo', ownerId: user.uid },
        { label: 'Churn', value: 2.4, unit: '%', ownerId: user.uid },
      ];

      await Promise.all(defaults.map(m => addDoc(collection(db, metricsPath), {
        ...m,
        updatedAt: new Date().toISOString()
      })));
      alert('Default metrics seeded.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, metricsPath);
    }
  };

  return (
    <div className="max-w-4xl space-y-8">
      <div className="glass-card p-6">
        <h3 className="text-lg font-serif italic mb-6 flex items-center gap-2">
          <Shield size={20} className="text-accent-founderos" /> Account
        </h3>
        <div className="space-y-4">
          <div className="flex justify-between items-center py-4 border-b border-white/5">
            <span className="text-sm text-gray-400 font-mono tracking-tight uppercase">User ID</span>
            <span className="text-sm font-mono">{user?.uid}</span>
          </div>
          <div className="flex justify-between items-center py-4 border-b border-white/5">
            <span className="text-sm text-gray-400 font-mono tracking-tight uppercase">Email</span>
            <span className="text-sm">{user?.email}</span>
          </div>
          <div className="flex justify-between items-center py-4">
            <span className="text-sm text-gray-400 font-mono tracking-tight uppercase">Status</span>
            <span className="px-2 py-1 rounded bg-green-500/20 text-green-500 text-[10px] uppercase font-bold tracking-widest">Active</span>
          </div>
        </div>
      </div>

      <div className="glass-card p-6">
        <h3 className="text-lg font-serif italic mb-6 flex items-center gap-2">
          <Database size={20} className="text-accent-founderos" /> Data Management
        </h3>
        <p className="text-sm text-gray-400 mb-6 leading-relaxed">
          Manage your operational data. Seeding will reset your dashboard metrics to standard founder KPIs.
        </p>
        <div className="flex gap-4">
          <button 
            onClick={seedMetrics}
            className="px-6 py-2 bg-white/5 border border-border-founderos rounded-lg text-sm font-medium hover:bg-white/10 transition-all flex items-center gap-2"
          >
            <Zap size={16} /> Seed Default Metrics
          </button>
        </div>
      </div>

      <div className="p-12 border border-dashed border-border-founderos rounded-2xl flex flex-col items-center justify-center text-center">
        <div className="text-accent-founderos mb-4">
          <SparklesIcon size={32} />
        </div>
        <h4 className="text-xl font-serif italic mb-2">Pro Plan Coming Soon</h4>
        <p className="text-gray-500 text-sm max-w-xs">
          Multi-user collaboration, automated CRM syncing, and scheduled investor reports are in development.
        </p>
      </div>
    </div>
  );
};

const SparklesIcon = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
    <path d="m5 3 1 1"/>
    <path d="m19 17 1 1"/>
    <path d="M19 3l1 1"/>
    <path d="m5 17 1 1"/>
  </svg>
)

export default Settings;
