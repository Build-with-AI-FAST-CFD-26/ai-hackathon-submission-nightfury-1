import React, { useState } from 'react';
import { useStore } from '../../store';
import { generateDraftStream } from '../../services/ai';
import { db, handleFirestoreError, OperationType } from '../../services/firebase';
import { collection, addDoc } from 'firebase/firestore';
import { Send, Copy, RotateCcw, Save, Sparkles, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const Drafts: React.FC = () => {
  const { user, context } = useStore();
  const [task, setTask] = useState('');
  const [generatedDraft, setGeneratedDraft] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const presets = [
    { label: 'Investor Update', prompt: 'Write a monthly investor update including high-level metrics, product wins, and "one big ask".' },
    { label: 'VC Outreach', prompt: 'Write a cold outreach email to a partner at a top-tier venture firm about our $2M seed round.' },
    { label: 'Customer Follow-up', prompt: 'Draft a message to a high-intent customer lead who went cold after a demo.' },
    { label: 'New Hire Welcome', prompt: 'Craft a warm, mission-driven welcome email to our first engineering hire.' },
  ];

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!task) return;
    
    setIsGenerating(true);
    setGeneratedDraft('');
    setSaved(false);

    const contextStr = context ? `
      Company: ${context.companyName}
      Vision: ${context.vision}
      Product: ${context.productDescription}
      Traction: ${context.traction}
    ` : 'No context provided.';

    try {
      await generateDraftStream(task, contextStr, (chunk) => {
        setGeneratedDraft(prev => prev + chunk);
      });
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedDraft);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = async () => {
    if (!user || !generatedDraft) return;
    try {
      const draftsPath = `users/${user.uid}/drafts`;
      await addDoc(collection(db, draftsPath), {
        title: task.slice(0, 50) + (task.length > 50 ? '...' : ''),
        content: generatedDraft,
        createdAt: new Date().toISOString(),
        ownerId: user.uid,
        type: 'AI Generation'
      });
      setSaved(true);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}/drafts`);
    }
  };

  return (
    <div className="grid grid-cols-12 gap-8 h-[calc(100vh-250px)]">
      {/* Input Section */}
      <div className="col-span-12 lg:col-span-5 flex flex-col gap-6">
        <div className="glass-card p-6 h-full">
          <label className="block text-xs font-mono uppercase tracking-widest text-gray-500 mb-4">
            What are we writing?
          </label>
          <form onSubmit={handleGenerate} className="space-y-4">
            <textarea
              value={task}
              onChange={(e) => setTask(e.target.value)}
              placeholder="Describe the task... (e.g. Follow up with Sequoia partner after our coffee chat)"
              className="w-full h-40 bg-white/5 border border-border-founderos rounded-xl px-4 py-4 focus:outline-none focus:border-accent-founderos transition-colors text-white resize-none"
            />
            <button
              disabled={isGenerating || !task}
              className="w-full py-4 bg-accent-founderos text-white font-semibold rounded-full hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-30"
            >
              <Sparkles size={18} />
              {isGenerating ? 'Drafting...' : 'Generate High-Stakes Draft'}
            </button>
          </form>

          <div className="mt-8">
            <label className="block text-[10px] font-mono uppercase tracking-widest text-gray-600 mb-3">
              Quick Presets
            </label>
            <div className="grid grid-cols-2 gap-2">
              {presets.map((preset) => (
                <button
                  key={preset.label}
                  onClick={() => setTask(preset.prompt)}
                  className="text-left p-3 text-xs border border-border-founderos rounded-lg hover:border-accent-founderos hover:bg-accent-founderos/5 transition-all text-gray-400 hover:text-white"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Output Section */}
      <div className="col-span-12 lg:col-span-7">
        <div className="glass-card h-full flex flex-col relative overflow-hidden">
          <div className="border-b border-border-founderos px-6 py-4 flex items-center justify-between bg-white/[0.02]">
            <span className="text-xs font-mono uppercase tracking-widest text-gray-500">Output</span>
            <div className="flex items-center gap-3">
              {generatedDraft && (
                <>
                  <button 
                    onClick={handleCopy}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors text-gray-400 hover:text-white"
                    title="Copy to clipboard"
                  >
                    {copied ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                  </button>
                  <button 
                    onClick={handleSave}
                    disabled={saved}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors text-gray-400 hover:text-white disabled:text-green-500"
                    title="Save to history"
                  >
                    {saved ? <Check size={16} /> : <Save size={16} />}
                  </button>
                  <button 
                    onClick={handleGenerate}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors text-gray-400 hover:text-white"
                    title="Regenerate"
                  >
                    <RotateCcw size={16} />
                  </button>
                </>
              )}
            </div>
          </div>

          <div className="flex-1 p-8 overflow-y-auto font-sans leading-relaxed text-gray-200">
            {isGenerating || generatedDraft ? (
              <div className="whitespace-pre-wrap">{generatedDraft}</div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-gray-600 text-center italic">
                <Sparkles size={48} className="mb-4 opacity-10" />
                Your ready-to-send draft will appear here.
              </div>
            )}
            {isGenerating && (
              <motion.span 
                animate={{ opacity: [0, 1, 0] }}
                transition={{ repeat: Infinity, duration: 1 }}
                className="inline-block w-1 h-5 bg-accent-founderos ml-1 align-middle"
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Drafts;
