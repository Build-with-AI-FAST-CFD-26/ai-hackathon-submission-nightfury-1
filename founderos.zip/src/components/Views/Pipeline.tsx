import React, { useEffect, useState } from 'react';
import { useStore } from '../../store';
import { db, handleFirestoreError, OperationType } from '../../services/firebase';
import { collection, addDoc, onSnapshot, updateDoc, doc, deleteDoc } from 'firebase/firestore';
import { Plus, Trash2, Calendar, DollarSign, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const Pipeline: React.FC = () => {
  const { user } = useStore();
  const [deals, setDeals] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [newDeal, setNewDeal] = useState({
    name: '',
    type: 'investor',
    stage: 'prospect',
    value: 0,
    notes: ''
  });

  useEffect(() => {
    if (!user) return;
    const dealsPath = `users/${user.uid}/deals`;
    const unsubscribe = onSnapshot(collection(db, dealsPath), (snapshot) => {
      const d = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setDeals(d);
    }, (err) => handleFirestoreError(err, OperationType.LIST, dealsPath));

    return () => unsubscribe();
  }, [user]);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newDeal.name) return;
    try {
      const dealsPath = `users/${user.uid}/deals`;
      await addDoc(collection(db, dealsPath), {
        ...newDeal,
        lastContactAt: new Date().toISOString(),
        ownerId: user.uid,
        createdAt: new Date().toISOString()
      });
      setIsAdding(false);
      setNewDeal({ name: '', type: 'investor', stage: 'prospect', value: 0, notes: '' });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}/deals`);
    }
  };

  const updateStage = async (id: string, stage: string) => {
    if (!user) return;
    const dealRef = doc(db, `users/${user.uid}/deals/${id}`);
    try {
      await updateDoc(dealRef, { 
        stage, 
        lastContactAt: new Date().toISOString() 
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, dealRef.path);
    }
  };

  const deleteDeal = async (id: string) => {
    if (!user || !window.confirm('Delete this deal?')) return;
    const dealRef = doc(db, `users/${user.uid}/deals/${id}`);
    try {
      await deleteDoc(dealRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, dealRef.path);
    }
  };

  const stages = [
    { id: 'prospect', label: 'Prospect' },
    { id: 'first-meeting', label: 'First Meeting' },
    { id: 'due-diligence', label: 'Due Diligence' },
    { id: 'term-sheet', label: 'Term Sheet' },
    { id: 'closed', label: 'Closed' },
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center gap-4">
          <button className="px-4 py-2 border border-border-founderos rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-white/5 transition-colors">
            <Filter size={16} /> All Types
          </button>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-white text-black px-6 py-2 rounded-full font-semibold flex items-center gap-2 hover:bg-gray-200 transition-colors"
        >
          <Plus size={18} /> Add Deal
        </button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden mb-8"
          >
            <form onSubmit={handleAdd} className="glass-card p-6 grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
              <div>
                <label className="block text-[10px] font-mono text-gray-500 uppercase mb-2">Deal Name</label>
                <input 
                  autoFocus
                  required
                  value={newDeal.name}
                  onChange={e => setNewDeal({...newDeal, name: e.target.value})}
                  className="w-full bg-white/5 border border-border-founderos rounded-lg px-3 py-2 text-sm text-white"
                  placeholder="Sequoia Capital"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-gray-500 uppercase mb-2">Type</label>
                <select 
                  value={newDeal.type}
                  onChange={e => setNewDeal({...newDeal, type: e.target.value})}
                  className="w-full bg-white/5 border border-border-founderos rounded-lg px-3 py-2 text-sm text-white"
                >
                  <option value="investor">Investor</option>
                  <option value="customer">Customer</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-mono text-gray-500 uppercase mb-2">Target Value</label>
                <input 
                  type="number"
                  value={newDeal.value}
                  onChange={e => setNewDeal({...newDeal, value: Number(e.target.value)})}
                  className="w-full bg-white/5 border border-border-founderos rounded-lg px-3 py-2 text-sm text-white"
                />
              </div>
              <div className="flex gap-2">
                <button type="submit" className="flex-1 bg-accent-founderos py-2 rounded-lg text-sm font-semibold">Save</button>
                <button type="button" onClick={() => setIsAdding(false)} className="px-4 py-2 border border-border-founderos rounded-lg text-sm font-medium">Cancel</button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="glass-card overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-white/[0.02] border-b border-border-founderos">
              <th className="px-6 py-4 text-left text-[10px] font-mono uppercase tracking-widest text-gray-500 font-medium">Name</th>
              <th className="px-6 py-4 text-left text-[10px] font-mono uppercase tracking-widest text-gray-500 font-medium">Stage</th>
              <th className="px-6 py-4 text-left text-[10px] font-mono uppercase tracking-widest text-gray-500 font-medium">Value</th>
              <th className="px-6 py-4 text-left text-[10px] font-mono uppercase tracking-widest text-gray-500 font-medium">Last Contact</th>
              <th className="px-6 py-4 text-right text-[10px] font-mono uppercase tracking-widest text-gray-500 font-medium whitespace-nowrap">Actions</th>
            </tr>
          </thead>
          <tbody>
            {deals.length > 0 ? (
              deals.map((deal) => (
                <tr key={deal.id} className="data-row">
                  <td className="px-6 py-4">
                    <div className="font-medium">{deal.name}</div>
                    <div className="text-[10px] font-mono uppercase text-gray-500 tracking-tight">{deal.type}</div>
                  </td>
                  <td className="px-6 py-4">
                    <select
                      value={deal.stage}
                      onChange={(e) => updateStage(deal.id, e.target.value)}
                      className={`text-sm focus:outline-none cursor-pointer transition-colors px-2 py-1 rounded select-none ${
                        deal.stage === 'closed' ? 'text-green-500 bg-green-500/10' : 
                        deal.stage === 'term-sheet' ? 'text-accent-founderos bg-accent-founderos/10 font-bold' :
                        'text-gray-300 hover:text-white'
                      }`}
                    >
                      {stages.map(s => <option key={s.id} value={s.id} className="bg-bg-founderos text-white">{s.label}</option>)}
                    </select>
                  </td>
                  <td className="px-6 py-4 font-mono text-sm">
                    <div className="flex items-center gap-1 group/val">
                      <span className="text-gray-500">$</span>
                      <input 
                        type="number"
                        defaultValue={deal.value}
                        onBlur={(e) => updateDoc(doc(db, `users/${user.uid}/deals/${deal.id}`), { value: Number(e.target.value) })}
                        className="bg-transparent w-24 focus:outline-none focus:bg-white/5 rounded px-1"
                      />
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <Calendar size={12} />
                      {new Date(deal.lastContactAt).toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => deleteDeal(deal.id)}
                      className="p-2 text-gray-600 hover:text-red-500 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500 italic text-sm">
                  Your deal pipeline is empty. Start by adding an investor or customer.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Pipeline;
