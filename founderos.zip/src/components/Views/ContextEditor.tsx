import React, { useEffect, useState } from 'react';
import { useStore } from '../../store';
import { db, handleFirestoreError, OperationType } from '../../services/firebase';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { Save, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const ContextEditor: React.FC = () => {
  const { user, setContext } = useStore();
  const [formData, setFormData] = useState({
    companyName: '',
    vision: '',
    productDescription: '',
    traction: '',
    team: '',
    idealInvestorProfile: ''
  });
  const [saving, setSaving] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    if (!user) return;
    const contextRef = doc(db, `users/${user.uid}/config/context`);
    
    const unsubscribe = onSnapshot(contextRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        setFormData(data as any);
        setContext(data as any);
      }
    }, (err) => handleFirestoreError(err, OperationType.GET, contextRef.path));

    return () => unsubscribe();
  }, [user, setContext]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    setSaving(true);
    try {
      const contextRef = doc(db, `users/${user.uid}/config/context`);
      await setDoc(contextRef, {
        ...formData,
        updatedAt: new Date().toISOString()
      });
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}/config/context`);
    } finally {
      setSaving(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const fields = [
    { name: 'companyName', label: 'Company Name', type: 'input', placeholder: 'e.g. FounderOS' },
    { name: 'vision', label: 'Vision & Mission', type: 'textarea', placeholder: 'Where are you going in 10 years?' },
    { name: 'productDescription', label: 'Product Description', type: 'textarea', placeholder: 'What do you build? Who is it for?' },
    { name: 'traction', label: 'Current Traction', type: 'textarea', placeholder: 'MRR, users, growth rate, retention...' },
    { name: 'team', label: 'Team', type: 'textarea', placeholder: 'Who are the founders? Key hires?' },
    { name: 'idealInvestorProfile', label: 'Ideal Investor Profile', type: 'textarea', placeholder: 'Stage, expertise, geography...' },
  ];

  return (
    <div className="max-w-4xl">
      <div className="mb-8">
        <p className="text-gray-400">
          This context is injected into every AI generation. The more specific you are, the better the drafts.
        </p>
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {fields.map((field) => (
            <div key={field.name} className={field.type === 'textarea' ? 'md:col-span-2' : ''}>
              <label className="block text-xs font-mono uppercase tracking-widest text-gray-500 mb-2">
                {field.label}
              </label>
              {field.type === 'input' ? (
                <input
                  name={field.name}
                  value={(formData as any)[field.name]}
                  onChange={handleChange}
                  placeholder={field.placeholder}
                  className="w-full bg-white/5 border border-border-founderos rounded-lg px-4 py-3 focus:outline-none focus:border-accent-founderos transition-colors text-white"
                />
              ) : (
                <textarea
                  name={field.name}
                  value={(formData as any)[field.name]}
                  onChange={handleChange}
                  placeholder={field.placeholder}
                  rows={4}
                  className="w-full bg-white/5 border border-border-founderos rounded-lg px-4 py-3 focus:outline-none focus:border-accent-founderos transition-colors text-white resize-none"
                />
              )}
            </div>
          ))}
        </div>

        <div className="flex items-center gap-4 pt-6">
          <button
            type="submit"
            disabled={saving}
            className="px-8 py-3 bg-white text-black font-semibold rounded-full hover:bg-gray-200 transition-colors flex items-center gap-2"
          >
            {saving ? 'Saving...' : (
              <>
                <Save size={18} />
                Save Context
              </>
            )}
          </button>
          
          <AnimatePresence>
            {showSuccess && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="text-green-500 flex items-center gap-2 text-sm font-medium"
              >
                <CheckCircle size={18} />
                Context updated
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </form>
    </div>
  );
};

export default ContextEditor;
