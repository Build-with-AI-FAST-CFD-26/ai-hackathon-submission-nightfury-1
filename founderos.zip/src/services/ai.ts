export const generateDraftStream = async (prompt: string, context: string, onChunk: (text: string) => void) => {
  try {
    const response = await fetch('/api/draft', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, context }),
    });

    if (!response.ok) throw new Error('Failed to generate draft');

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();

    if (!reader) return;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n');

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6);
          if (data === '[DONE]') break;
          try {
            const { text } = JSON.parse(data);
            if (text) onChunk(text);
          } catch (e) {
            // Partial JSON or heartbeat
          }
        }
      }
    }
  } catch (error) {
    console.error("AI Streaming Error:", error);
    throw error;
  }
};
