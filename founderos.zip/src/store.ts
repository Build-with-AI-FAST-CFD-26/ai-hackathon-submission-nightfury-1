import { create } from 'zustand';
import { User } from 'firebase/auth';

interface FounderContext {
  companyName: string;
  vision: string;
  productDescription: string;
  traction: string;
  team: string;
  idealInvestorProfile: string;
}

interface AppState {
  user: User | null;
  context: FounderContext | null;
  setUser: (user: User | null) => void;
  setContext: (context: FounderContext | null) => void;
}

export const useStore = create<AppState>((set) => ({
  user: null,
  context: null,
  setUser: (user) => set({ user }),
  setContext: (context) => set({ context }),
}));
