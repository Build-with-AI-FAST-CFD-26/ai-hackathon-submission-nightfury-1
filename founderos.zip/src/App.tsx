import React, { useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, signIn, signOut } from './services/firebase';
import { useStore } from './store';
import { 
  Drafts, 
  ContextEditor, 
  Pipeline, 
  Dashboard, 
  Settings 
} from './components/Views';
import Sidebar from './components/Sidebar';
import { LayoutDashboard, PenTool, GitPullRequest, Database, Settings as SettingsIcon, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const { user, setUser, context } = useStore();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return () => unsubscribe();
  }, [setUser]);

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-bg-founderos overflow-hidden">
        <motion.div 
          animate={{ opacity: [0.3, 1, 0.3] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="text-white font-serif italic text-4xl"
        >
          FounderOS
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-bg-founderos px-4">
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-center max-w-md"
        >
          <h1 className="text-6xl font-serif italic mb-6">FounderOS</h1>
          <p className="text-gray-400 mb-12 text-lg">
            Your AI co-pilot for high-stakes growth. Manage context, generate drafts, and track your deal pipeline.
          </p>
          <button 
            onClick={signIn}
            className="w-full py-4 bg-white text-black font-semibold rounded-full hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
          >
            Connect with Google
          </button>
        </motion.div>
      </div>
    );
  }

  const renderView = () => {
    switch(activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'drafts': return <Drafts />;
      case 'pipeline': return <Pipeline />;
      case 'context': return <ContextEditor />;
      case 'settings': return <Settings />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-bg-founderos">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 overflow-y-auto px-8 pt-8 pb-12">
        <header className="flex justify-between items-center mb-12">
          <div>
            <h2 className="text-sm font-mono uppercase tracking-widest text-accent-founderos mb-1">
              {activeTab}
            </h2>
            <h1 className="text-3xl font-serif italic">
              {activeTab === 'dashboard' ? `Welcome, ${user.displayName?.split(' ')[0]}` : activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs font-mono text-gray-500 uppercase tracking-tighter">Live Session</div>
              <div className="text-sm font-medium">{user.email}</div>
            </div>
            <button 
              onClick={signOut}
              className="p-2 hover:bg-white/10 rounded-full transition-colors text-gray-400 hover:text-white"
            >
              <LogOut size={18} />
            </button>
          </div>
        </header>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
